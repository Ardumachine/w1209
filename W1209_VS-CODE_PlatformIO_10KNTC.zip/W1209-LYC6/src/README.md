# w1209-firmware
The functional equivalent to the original firmware of "Digital Thermostat Module Model XH-W1209".

The F.A.Q. page is available at https://github.com/mister-grumbler/w1209-firmware/wiki/FAQ

Look at the list of issues to have an idea of what needs to be done for the initial release.
https://github.com/mister-grumbler/w1209-firmware/issues
